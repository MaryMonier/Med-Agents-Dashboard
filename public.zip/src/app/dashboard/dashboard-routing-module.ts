import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Home } from './home/home';
import { ConsultationFormComponent } from '../consultations/consultation-form/consultation-form';

const routes: Routes = [
  {path:'',component: Home}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DashboardRoutingModule {}
