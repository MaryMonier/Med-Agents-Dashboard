import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { Subject, forkJoin, takeUntil } from 'rxjs';
import {
  ChartConfiguration,
  ChartData,
  ChartType,
  Chart,
} from 'chart.js';
import {
  LineController,
  LineElement,
  BarController,
  BarElement,
  PointElement,
  CategoryScale,
  LinearScale,
  Filler,
  Tooltip,
  Legend,
} from 'chart.js';
import { BaseChartDirective } from 'ng2-charts';

import { Sidebar } from '../../shared/sidebar/sidebar';
import { Navbar } from '../../shared/navbar/navbar';
import {
  DashboardService,
  ChartPeriod,
  DashboardStats,
  ConsultationSummary,
  ChartDataPoint,
} from '../../services/dashboard.service';

Chart.register(
  LineController,
  LineElement,
  BarController,
  BarElement,
  PointElement,
  CategoryScale,
  LinearScale,
  Filler,
  Tooltip,
  Legend
);

export interface StatCard {
  label: string;
  value: number;
  icon: string;
  trend: number;
  trendLabel: string;
  accentClass: string;
  loading: boolean;
}

export interface RecentPatientRow {
  id: string;
  name: string;
  initials: string;
  avatarColor: string;
  condition: string;
  urgency: 'low' | 'medium' | 'critical';
  time: string;
  status: 'completed' | 'pending' | 'follow-up';
}

// ── Avatar colour palette (deterministic per name) ─────────────────
const AVATAR_COLORS = [
  '#E6F1FB', '#E6FBF3', '#FBF3E6',
  '#F3E6FB', '#FBE6E6', '#E6F8FB',
];
function avatarColor(index: number): string {
  return AVATAR_COLORS[index % AVATAR_COLORS.length];
}
function initials(name: string): string {
  return (name ?? '?')
    .split(' ')
    .slice(0, 2)
    .map((w) => w[0])
    .join('')
    .toUpperCase();
}
function timeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60_000);
  if (mins < 1)  return 'just now';
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs  < 24) return `${hrs} hr ago`;
  return `${Math.floor(hrs / 24)} days ago`;
}

// ── Chart helpers ─────────────────────────────────────────────────
function buildChartLabels(period: ChartPeriod): string[] {
  if (period === 'week') return ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  if (period === 'month') {
    const today = new Date();
    return Array.from({ length: 4 }, (_, i) => `Week ${i + 1}`);
  }
  return ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
          'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'].slice(0, 3);
}

function aggregateToChartPoints(
  consultations: ConsultationSummary[],
  followups: any[],
  period: ChartPeriod
): ChartDataPoint[] {
  const now = new Date();

  const bucketOf = (dateStr: string): number => {
    const d = new Date(dateStr);
    if (period === 'week') return d.getDay() === 0 ? 6 : d.getDay() - 1; // Mon=0
    if (period === 'month') return Math.floor((now.getDate() - d.getDate()) / 7);
    return d.getMonth();
  };

  const rangeMs: Record<ChartPeriod, number> = {
    week:    7  * 86_400_000,
    month:   30 * 86_400_000,
    quarter: 90 * 86_400_000,
  };
  const cutoff = now.getTime() - rangeMs[period];

  const buckets = period === 'week'   ? 7
                : period === 'month'  ? 4
                :                      3;

  const cBuckets = new Array(buckets).fill(0);
  const fBuckets = new Array(buckets).fill(0);

  consultations
    .filter((c) => new Date(c.createdAt).getTime() > cutoff)
    .forEach((c) => {
      const b = Math.max(0, Math.min(buckets - 1, bucketOf(c.createdAt)));
      cBuckets[b]++;
    });

  followups
    .filter((f) => new Date(f.createdAt).getTime() > cutoff)
    .forEach((f) => {
      const b = Math.max(0, Math.min(buckets - 1, bucketOf(f.createdAt)));
      fBuckets[b]++;
    });

  const labels = buildChartLabels(period);
  return labels.map((label, i) => ({
    label,
    consultations: cBuckets[i],
    followups: fBuckets[i],
  }));
}

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterModule, BaseChartDirective, Sidebar, Navbar],
  templateUrl: './home.html',
  styleUrls: ['./home.css'],
})
export class HomeComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();

  // ── State flags ─────────────────────────────────────────────────
  statsLoading      = true;
  patientsLoading   = true;
  chartLoading      = false;
  exportLoading     = false;
  statsError        = false;
  patientsError     = false;

  // ── UI State ─────────────────────────────────────────────────────
  currentDate      = '';
  activePeriod: ChartPeriod = 'week';

  // ── Stat Cards ───────────────────────────────────────────────────
  statCards: StatCard[] = [
    { label: 'Total Patients',        value: 0, icon: 'ti ti-users',               trend: 0, trendLabel: 'registered',        accentClass: 'accent-blue',   loading: true },
    { label: 'Consultations',         value: 0, icon: 'ti ti-stethoscope',          trend: 0, trendLabel: 'total sessions',     accentClass: 'accent-teal',   loading: true },
    { label: 'Drug Safety Warnings',  value: 0, icon: 'ti ti-shield-exclamation',   trend: 0, trendLabel: 'critical urgency',   accentClass: 'accent-amber',  loading: true },
    { label: 'Active Follow-ups',     value: 0, icon: 'ti ti-calendar-check',       trend: 0, trendLabel: 'pending review',     accentClass: 'accent-violet', loading: true },
  ];

  // ── Recent Patients ──────────────────────────────────────────────
  recentPatients: RecentPatientRow[] = [];

  // ── Chart ────────────────────────────────────────────────────────
  lineChartType: ChartType = 'line';

  lineChartData: ChartData<'line'> = {
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    datasets: [
      {
        label: 'Consultations',
        data: [0, 0, 0, 0, 0, 0, 0],
        borderColor: '#185FA5',
        backgroundColor: 'rgba(24, 95, 165, 0.08)',
        borderWidth: 2.5,
        pointBackgroundColor: '#185FA5',
        pointBorderColor: '#ffffff',
        pointBorderWidth: 2,
        pointRadius: 5,
        pointHoverRadius: 7,
        tension: 0.4,
        fill: true,
      },
      {
        label: 'Follow-ups',
        data: [0, 0, 0, 0, 0, 0, 0],
        borderColor: '#0D9488',
        backgroundColor: 'rgba(13, 148, 136, 0.06)',
        borderWidth: 2,
        pointBackgroundColor: '#0D9488',
        pointBorderColor: '#ffffff',
        pointBorderWidth: 2,
        pointRadius: 4,
        pointHoverRadius: 6,
        tension: 0.4,
        fill: true,
      },
    ],
  };

  lineChartOptions: ChartConfiguration['options'] = {
    responsive: true,
    maintainAspectRatio: false,
    interaction: { mode: 'index', intersect: false },
    scales: {
      x: {
        grid:   { display: false },
        border: { display: false },
        ticks:  { color: '#94a3b8', font: { size: 12, family: "'DM Sans', sans-serif" }, padding: 8 },
      },
      y: {
        grid:   { color: 'rgba(148,163,184,0.15)', tickLength: 0 },
        border: { display: false, dash: [4, 4] },
        ticks:  { color: '#94a3b8', font: { size: 12, family: "'DM Sans', sans-serif" }, padding: 12, stepSize: 2 },
        beginAtZero: true,
      },
    },
    plugins: {
      legend: {
        display: true,
        position: 'top',
        align: 'end',
        labels: {
          color: '#64748b',
          font: { size: 12, family: "'DM Sans', sans-serif" },
          usePointStyle: true,
          pointStyle: 'circle',
          boxWidth: 7,
          boxHeight: 7,
          padding: 20,
        },
      },
      tooltip: {
        backgroundColor: '#ffffff',
        titleColor: '#1e293b',
        bodyColor: '#64748b',
        borderColor: '#e2e8f0',
        borderWidth: 1,
        padding: 12,
        cornerRadius: 10,
        boxPadding: 4,
        titleFont: { size: 13, weight: 'bold', family: "'DM Sans', sans-serif" },
        bodyFont:  { size: 12, family: "'DM Sans', sans-serif" },
      },
    },
  };

  // Cache raw data for client-side chart re-aggregation
  private allConsultations: ConsultationSummary[] = [];
  private allFollowups: any[] = [];

  constructor(
    private dashboardService: DashboardService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  // ── Lifecycle ────────────────────────────────────────────────────
  ngOnInit(): void {
    this.currentDate = new Date().toLocaleDateString('en-US', {
      weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
    });
    this.loadAll();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  // ── Data Loading ─────────────────────────────────────────────────
  public loadAll(): void {
    this.loadStats();
    this.loadRecentPatients();
    this.loadChartData('week');
  }

  private loadStats(): void {
    this.statsLoading = true;
    this.statsError   = false;

    this.dashboardService
      .getStats()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (stats: DashboardStats) => {
          this.statCards[0].value   = stats.totalPatients;
          this.statCards[0].trend   = stats.totalPatients;
          this.statCards[1].value   = stats.totalConsultations;
          this.statCards[1].trend   = stats.totalConsultations;
          this.statCards[2].value   = stats.drugWarningsCount;
          this.statCards[2].trend   = stats.drugWarningsCount;
          this.statCards[3].value   = stats.activeFollowups;
          this.statCards[3].trend   = stats.activeFollowups;
          this.statCards.forEach(c => (c.loading = false));
          this.statsLoading = false;
          this.cdr.markForCheck();
        },
        error: () => {
          this.statsError   = true;
          this.statsLoading = false;
          this.statCards.forEach(c => (c.loading = false));
          this.cdr.markForCheck();
        },
      });
  }

  private loadRecentPatients(): void {
    this.patientsLoading = true;
    this.patientsError   = false;

    this.dashboardService
      .getRecentConsultations(6)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (consultations: ConsultationSummary[]) => {
          this.recentPatients = consultations.map((c, i): RecentPatientRow => {
            const patient = c.patientId;
            const name    = patient?.name ?? 'Unknown Patient';
            return {
              id:          c._id,
              name,
              initials:    initials(name),
              avatarColor: avatarColor(i),
              condition:   c.diagnosis || 'Consultation recorded',
              urgency:     c.urgencyLevel,
              time:        timeAgo(c.createdAt),
              status:      c.status === 'completed' ? 'completed' : 'pending',
            };
          });
          this.patientsLoading = false;
          this.cdr.markForCheck();
        },
        error: () => {
          this.patientsError   = true;
          this.patientsLoading = false;
          this.cdr.markForCheck();
        },
      });
  }

  // ── Chart ─────────────────────────────────────────────────────────
  loadChartData(period: ChartPeriod): void {
    this.activePeriod = period;
    this.chartLoading = true;

    // Try dedicated analytics endpoint first; fall back to client aggregation
    this.dashboardService
      .getChartData(period)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (res) => {
          this.applyChartPoints(res.data, period);
          this.chartLoading = false;
          this.cdr.markForCheck();
        },
        error: () => {
          // Fallback: aggregate from raw list endpoints
          this.buildChartFromRawData(period);
        },
      });
  }

  private buildChartFromRawData(period: ChartPeriod): void {
    forkJoin({
      consultations: this.dashboardService.getAllConsultationsForChart(),
      followups:     this.dashboardService.getAllFollowupsForChart(),
    })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: ({ consultations, followups }) => {
          this.allConsultations = consultations;
          this.allFollowups     = followups;
          const points = aggregateToChartPoints(consultations, followups, period);
          this.applyChartPoints(points, period);
          this.chartLoading = false;
          this.cdr.markForCheck();
        },
        error: () => {
          this.chartLoading = false;
          this.cdr.markForCheck();
        },
      });
  }

  private applyChartPoints(points: ChartDataPoint[], period: ChartPeriod): void {
    const labels         = points.map(p => p.label);
    const consultations  = points.map(p => p.consultations);
    const followups      = points.map(p => p.followups);

    this.lineChartData = {
      ...this.lineChartData,
      labels,
      datasets: [
        { ...this.lineChartData.datasets[0], data: consultations },
        { ...this.lineChartData.datasets[1], data: followups },
      ],
    };
  }

  // ── Actions ───────────────────────────────────────────────────────

  /**
   * Export Report — picks the most recent consultation, calls the
   * AI report generation endpoint, then triggers a plain-text download.
   * Swap the download logic for a PDF blob when a PDF endpoint exists.
   */
  exportReport(): void {
    if (this.exportLoading) return;

    if (this.allConsultations.length === 0 && this.recentPatients.length === 0) {
      alert('No consultations available to export.');
      return;
    }

    const latestId = this.recentPatients[0]?.id ?? this.allConsultations[0]?._id;
    if (!latestId) return;

    this.exportLoading = true;

    this.dashboardService
      .generateReport(latestId)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (res: any) => {
          const report = res.data ?? res;
          const content = [
            `MED AGENTS — MEDICAL REPORT`,
            `Generated: ${new Date().toLocaleString()}`,
            `${'─'.repeat(60)}`,
            `Title:              ${report.reportTitle           ?? 'N/A'}`,
            `Patient Condition:  ${report.patientCondition      ?? 'N/A'}`,
            `Clinical Findings:  ${report.clinicalFindings      ?? 'N/A'}`,
            `Treatment Plan:     ${report.treatmentPlan         ?? 'N/A'}`,
            `Recommendations:    ${report.recommendations       ?? 'N/A'}`,
            `Follow-up Notes:    ${report.followupNotes         ?? 'N/A'}`,
          ].join('\n');

          const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
          const url  = URL.createObjectURL(blob);
          const a    = document.createElement('a');
          a.href     = url;
          a.download = `med-report-${Date.now()}.txt`;
          a.click();
          URL.revokeObjectURL(url);
          this.exportLoading = false;
          this.cdr.markForCheck();
        },
        error: () => {
          alert('Report generation failed. Please try again.');
          this.exportLoading = false;
          this.cdr.markForCheck();
        },
      });
  }

  /** Routes to the new-consultation form */
  newConsultation(): void {
    this.router.navigate(['/dashboard/consultations/add']);
  }

  // ── Template helpers ──────────────────────────────────────────────
  getUrgencyLabel(urgency: string): string {
    return ({ low: 'Low', medium: 'Moderate', critical: 'Critical' } as any)[urgency] ?? urgency;
  }

  getStatusLabel(status: string): string {
    return ({ completed: 'Completed', pending: 'Pending', 'follow-up': 'Follow-up' } as any)[status] ?? status;
  }

  trackById(_: number, item: RecentPatientRow): string { return item.id; }

  // Convenience getters for stats / warning banner
  get totalPatients():      number { return this.statCards[0].value; }
  get totalConsultations(): number { return this.statCards[1].value; }
  get totalWarnings():      number { return this.statCards[2].value; }
  get totalFollowups():     number { return this.statCards[3].value; }
}
